#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <random>
#include <fstream>

// g++ -pipe -Ofast -std=c++11 clustering.cpp -o clustering

using namespace std;

class point
{

private:

	float positionX, positionY;
	int32_t groupe;

public:

	point(float positionX, float positionY, int32_t groupe)
	{
		this->positionX = positionX;
		this->positionY = positionY;
		this->groupe = groupe;
	}

	~point()
	{
	}

	float getPositionX()
	{
		return positionX;
	}

	float getPositionY()
	{
		return positionY;
	}

	int32_t getGroupe()
	{
		return groupe;
	}

	void setPositionX(float positionX)
	{
		this->positionX = positionX;
	}

	void setPositionY(float positionY)
	{
		this->positionY = positionY;
	}

	void setGroupe(int32_t groupe)
	{
		this->groupe = groupe;
	}
};

float getDistance(float x1, float y1, float x2, float y2)
{
	return sqrt(pow(x1-x2,2) + pow(y1-y2,2));
}

bool clustering(vector<point> &pointsVecteur, vector<point> &centroidesVecteur, float seuil)
{
	// clustering
	for (uint32_t i=0; i<pointsVecteur.size(); i++)
	{
		bool gagnantDefini = false;
		uint32_t gagnant = 0;
		float distance = 0;
		for (uint32_t j=0; j<centroidesVecteur.size(); j++)
		{
			if (gagnantDefini == false)
			{
				gagnant = j;
				distance = getDistance(pointsVecteur[i].getPositionX(), pointsVecteur[i].getPositionY(), centroidesVecteur[j].getPositionX(), centroidesVecteur[j].getPositionY());
				gagnantDefini = true;
			}
			else
			{
				float tmp = getDistance(pointsVecteur[i].getPositionX(), pointsVecteur[i].getPositionY(), centroidesVecteur[j].getPositionX(), centroidesVecteur[j].getPositionY());
				if (tmp < distance)
				{
					distance = tmp;
					gagnant = j;
				}
			}
		}

		// Changer de groupe
		pointsVecteur[i].setGroupe(centroidesVecteur[gagnant].getGroupe());
	}

	uint32_t compteurSeuil = 0;

	// Calculer le barycentre de chaque zone et deplacer le centroid
	for (uint32_t i=0; i<centroidesVecteur.size(); i++)
	{
		float barycentreX = 0;
		float barycentreY = 0;
		uint32_t compteur = 0;

		// Calcul du barycentre
		for (uint32_t j=0; j<pointsVecteur.size(); j++)
		{
			if (pointsVecteur[j].getGroupe() == centroidesVecteur[i].getGroupe())
			{
				compteur++;
				barycentreX += pointsVecteur[j].getPositionX();
				barycentreY += pointsVecteur[j].getPositionY();
			}
		}

		// Changer la position du centroid
		if (compteur > 0)
		{
			float nouveauBarycentreX = barycentreX/compteur;
			float nouveauBarycentreY = barycentreY/compteur;

			float differenceX = (abs(centroidesVecteur[i].getPositionX()-nouveauBarycentreX))/((centroidesVecteur[i].getPositionX()+nouveauBarycentreX)/2);
			float differenceY = (abs(centroidesVecteur[i].getPositionY()-nouveauBarycentreY))/((centroidesVecteur[i].getPositionY()+nouveauBarycentreY)/2);

			if (differenceX <= seuil && differenceY <= seuil)
			{
				compteurSeuil++;
			}

			centroidesVecteur[i].setPositionX(nouveauBarycentreX);
			centroidesVecteur[i].setPositionY(nouveauBarycentreY);
		}
		else
		{
			compteurSeuil++;
		}
	}

	if (compteurSeuil == centroidesVecteur.size())
	{
		return true;
	}
	else
	{
		return false;
	}

}

void parserFichier(char * &fichier, uint32_t tailleFichier, vector<point> &pointsVecteur, float &positionXmin, float &positionXmax, float &positionYmin, float &positionYmax)
{
	string ligne = "";
	ligne.reserve(128);

	string valeur1string = "";
	valeur1string.reserve(16);

	string valeur2string = "";
	valeur2string.reserve(16);

	bool positionMinDef = false;

	for (uint32_t i=0; i<tailleFichier; i++)
	{
		if (!(fichier[i] == '\n' || fichier[i] == 0x0A))
		{
			ligne += fichier[i];
		}
		else if (ligne.length() > 0)
		{
			// Recuper les deux valeurs de la ligne
			valeur1string = "";
			valeur2string = "";

			uint32_t positionSeparateur = 0;

			for (uint32_t j=0; j<ligne.length(); j++)
			{
				if ((ligne[j] >= 48 && ligne[j] <= 57) || ligne[j] == 46)
				{
					valeur1string += ligne[j];
				}
				else
				{
					positionSeparateur = j;
					break;
				}
			}

			if (positionSeparateur != 0)
			{
				for (uint32_t j=positionSeparateur+1; j<ligne.length(); j++)
				{
					if ((ligne[j] >= 48 && ligne[j] <= 57) || ligne[j] == 46)
					{
						valeur2string += ligne[j];
					}
					else
					{
						break;
					}
				}
			}

			//cout << "string : " << valeur1string << ", " << valeur2string << endl;
			if (valeur1string.length() > 0 && valeur2string.length() > 0)
			{
				float valeur1=0, valeur2=0;
				bool reussite = false;

				try
				{
					valeur1 = stof(valeur1string);
					valeur2 = stof(valeur2string);
					reussite = true;
				}
				catch(...)
				{
					//cerr << "Erreur de conversion de string en float" << endl;
				}

				//cout << valeur1 << ", " << valeur2 << endl;

				if (reussite == true)
				{
					if (positionMinDef == false)
					{
						positionXmin = valeur1;
						positionXmax = valeur1;
						positionYmin = valeur2;
						positionYmax = valeur2;
						positionMinDef = true;
					}
					else
					{
						if (valeur1 < positionXmin)
						{
							positionXmin = valeur1;
						}
						else if (valeur1 > positionXmax)
						{
							positionXmax = valeur1;
						}

						if (valeur2 < positionYmin)
						{
							positionYmin = valeur2;
						}
						else if (valeur2 > positionYmax)
						{
							positionYmax = valeur2;
						}
					}

					pointsVecteur.push_back(point(valeur1, valeur2, -1));
				}
			}
			ligne = "";
		}
	}
}

void getCouleur(int position, float &r, float &v, float &b)
{
	switch (position)
	{
	case -1:
		r=0;
		v=0;
		b=1;
		break;
	case 0:
		r=0.356863;
		v=0.235294;
		b=0.0666667;
		break;
	case 1:
		r=0.352941;
		v=0.368627;
		b=0.419608;
		break;
	case 2:
		r=0;
		v=1;
		b=0;
		break;
	case 3:
		r=0.972549;
		v=0.556863;
		b=0.333333;
		break;
	case 4:
		r=0.780392;
		v=0.172549;
		b=0.282353;
		break;
	case 5:
		r=0.6;
		v=0.478431;
		b=0.564706;
		break;
	case 6:
		r=0.654902;
		v=0.403922;
		b=0.14902;
		break;
	case 7:
		r=0.858824;
		v=0.0901961;
		b=0.00784314;
		break;
	case 8:
		r=1;
		v=0.435294;
		b=0.490196;
		break;
	case 9:
		r=0.87451;
		v=0.45098;
		b=1;
		break;
	case 10:
		r=0.929412;
		v=0.498039;
		b=0.0627451;
		break;
	case 11:
		r=0.870588;
		v=0.192157;
		b=0.388235;
		break;
	case 12:
		r=0.00392157;
		v=0.843137;
		b=0.345098;
		break;
	case 13:
		r=0.533333;
		v=0.258824;
		b=0.113725;
		break;
	case 14:
		r=0.517647;
		v=0.180392;
		b=0.105882;
		break;
	case 15:
		r=1;
		v=0;
		b=0.498039;
		break;
	case 16:
		r=0.878431;
		v=0.0666667;
		b=0.372549;
		break;
	case 17:
		r=0.784314;
		v=0.678431;
		b=0.498039;
		break;
	case 18:
		r=1;
		v=0.796078;
		b=0.376471;
		break;
	case 19:
		r=0.807843;
		v=0.807843;
		b=0.807843;
		break;
	case 20:
		r=0.972549;
		v=0.556863;
		b=0.333333;
		break;
	case 21:
		r=0.498039;
		v=0.866667;
		b=0.298039;
		break;
	case 22:
		r=1;
		v=0;
		b=0;
		break;
	case 23:
		r=1;
		v=0;
		b=1;
		break;
	case 24:
		r=0.4;
		v=0;
		b=0.6;
		break;
	case 25:
		r=0.905882;
		v=0.243137;
		b=0.00392157;
		break;
	case 26:
		r=0.733333;
		v=0.823529;
		b=0.882353;
		break;
	case 27:
		r=0.905882;
		v=0.243137;
		b=0.00392157;
		break;
	case 28:
		r=0.984314;
		v=0.94902;
		b=0.717647;
		break;
	case 29:
		r=0.105882;
		v=0.309804;
		b=0.0313726;
		break;
	case 30:
		r=0.976471;
		v=0.258824;
		b=0.619608;
		break;
	case 31:
		r=0.831373;
		v=0.45098;
		b=0.831373;
		break;
	case 32:
		r=0.941176;
		v=0.764706;
		b=0;
		break;
	case 33:
		r=0.376471;
		v=0.376471;
		b=0.376471;
		break;
	case 34:
		r=0.0941176;
		v=0.223529;
		b=0.117647;
		break;
	case 35:
		r=1;
		v=0.796078;
		b=0.376471;
		break;
	case 36:
		r=0.992157;
		v=0.423529;
		b=0.619608;
		break;
	case 37:
		r=0.533333;
		v=0.301961;
		b=0.654902;
		break;
	case 38:
		r=0.937255;
		v=0.607843;
		b=0.0588235;
		break;
	case 39:
		r=1;
		v=1;
		b=0;
		break;
	default:
		r=0;
		v=0;
		b=0;
		break;
	}
}

void genererCSV(string &output, vector<point> &pointsVecteur)
{
	for (uint32_t i=0; i<pointsVecteur.size(); i++)
	{
		output += to_string(pointsVecteur[i].getPositionX());
		output += ";";
		output += to_string(pointsVecteur[i].getPositionY());
		output += ";";
		output += to_string(pointsVecteur[i].getGroupe());
		output += ";\n";
	}
}

void genererEPS(string &output, vector<point> &pointsVecteur, float positionXmin, float positionXmax, float positionYmin, float positionYmax, int taillePoints)
{
	if (taillePoints <= 0 || taillePoints > 100)
	{
		taillePoints = 5;
	}

	const float offset = 30;

	output = "%!\n";
	output += "%%BoundingBox: 0 0 " + to_string(uint32_t(positionXmax-positionXmin + offset)) + " " + to_string(uint32_t(positionYmax-positionYmin + offset)) + '\n';

	// Afficher les points
	for (uint32_t i=0; i<pointsVecteur.size(); i++)
	{
		float r, v, b;
		getCouleur(pointsVecteur[i].getGroupe(), r, v, b);

		output += to_string(positionXmin+pointsVecteur[i].getPositionX()-offset/2) + " " + to_string(pointsVecteur[i].getPositionY()-positionYmin+offset/2) + " translate " + to_string(r) + " " + to_string(v) + " " + to_string(b) + " newpath 0 0 moveto 0 " + to_string(taillePoints) + " rlineto " + to_string(taillePoints) + " 0 rlineto 0 " + to_string(-1*taillePoints) + " rlineto closepath setrgbcolor fill grestore stroke\n";
	}

	output += "%%EOF\n";
}

int main(int argc, char **argv)
{
	//cout << "K-means" << endl;

	// Fichier, nombre centroides, format
	if (argc < 8)
	{
		cerr << "Arguments : fichier, nombre K-means, nombre centroides, seuil K-means, seuil single link, fichier intermediaire (oui, non), format (csv, eps), taille point (optionnel)" << endl;
		exit(1);
	}

	uint32_t nombreKmeansUtilisateur, nombreCentroides, taillePoint = 1;
	float seuilKmeans;
	uint8_t seuilSingleLink;

	try
	{
		nombreKmeansUtilisateur = stoi(string(argv[2]));
		nombreCentroides = stoi(string(argv[3]));
		seuilKmeans = stof(string(argv[4]));
		seuilSingleLink = stoi(string(argv[5]));

		if (argc >= 9)
		{
			taillePoint = stoi(string(argv[8]));
		}
	}
	catch(...)
	{
		cerr << "Erreur d'argument" << endl;
		exit(1);
	}

	if (nombreKmeansUtilisateur > 100 || nombreKmeansUtilisateur == 0) nombreKmeansUtilisateur = 10;
	if (nombreCentroides > 100 ||nombreCentroides == 0) nombreCentroides = 10;
	if (seuilKmeans > 1 || seuilKmeans < 0.0001) seuilKmeans = 0.001;
	if (seuilSingleLink > 100 || seuilSingleLink == 0) seuilSingleLink = 5;
	if (taillePoint > 15 || taillePoint == 0) taillePoint = 1;

	bool fichiersIntermediaires = false;
	if (string(argv[6]) == "oui")
	{
		fichiersIntermediaires = true;
	}

	bool formatEPS = false;
	if (string(argv[7]) == "eps")
	{
		formatEPS = true;
	}

	// Lecture du fichier
	char *  fichier;
	uint32_t tailleFichier;
	ifstream file (argv[1], ios::in|ios::binary|ios::ate);
	if (file.is_open())
	{
		tailleFichier = file.tellg();
		fichier = new char [tailleFichier];
		file.seekg (0, ios::beg);
		file.read (fichier, tailleFichier);
		if (!file)
		{
			cout << "Erreur de lecture du fichier" << endl;
			exit(1);
		}
		file.close();
	}
	else
	{
		cout << "Pas de fichier file.txt" << endl;
		exit(1);
	}

	cout << "---------------------" << endl;
	cout << "nom du fichier : " << argv[1] << endl;
	cout << "Nombre de K-means : " << nombreKmeansUtilisateur << endl;
	cout << "Nombre de centroides : " << nombreCentroides << endl;
	cout << "Seuil des K-means : " << seuilKmeans << endl;
	cout << "Seuil single link : " << (int)seuilSingleLink << endl;
	cout << "Fichier intermédiaire : " << ((fichiersIntermediaires == true) ? "oui" : "non") << endl;
	cout << "Format de sortie : " << ((formatEPS == true) ? "eps" : "csv") << endl;
	if (formatEPS == true)
	{
		cout << "Taille des points : " << taillePoint << endl;
	}

	cout << "---------------------" << endl;


	//cout << "Taille fichier : " << tailleFichier << endl;

	vector<point> pointsVecteur;
	pointsVecteur.reserve(1000*10);

	float positionXminParser, positionXmaxParser, positionYminParser, positionYmaxParser;
	parserFichier(fichier, tailleFichier, pointsVecteur, positionXminParser, positionXmaxParser, positionYminParser, positionYmaxParser);

	if (pointsVecteur.size() == 0)
	{
		cerr << "Aucun points n'a été ajouté, mauvais format de fichier" << endl;
		exit(1);
	}

	string output = "";
	output.reserve(1024*16);

	uint8_t** matrice = new uint8_t * [pointsVecteur.size()];
	for(uint32_t i = 0; i < pointsVecteur.size(); i++)
	{
		matrice[i] = new uint8_t[pointsVecteur.size()];
	}

	random_device generator;
	uniform_real_distribution<float> distributionX(positionXminParser,positionXmaxParser);
	uniform_real_distribution<float> distributionY(positionYminParser,positionYmaxParser);

	vector<point> centroidesVecteur;
	centroidesVecteur.reserve(10);


	for (uint32_t nombreKmeans = 0; nombreKmeans < nombreKmeansUtilisateur; nombreKmeans++)
	{
		// Kmeans 1

		// Generer des centroides
		centroidesVecteur.clear();
		for (uint32_t i=0; i<nombreCentroides; i++)
		{
			centroidesVecteur.push_back(point(distributionX(generator), distributionY(generator), centroidesVecteur.size()));
		}
		// Clustering

		while(clustering(pointsVecteur, centroidesVecteur, seuilKmeans) == false);


		// Incrémentation de la matrice
		for(uint32_t i = 0; i < pointsVecteur.size(); i++)
		{
			for(uint32_t j = 0; j < pointsVecteur.size(); j++)
			{
				//if (i == j) break;
				/*else*/ if (pointsVecteur[i].getGroupe() == pointsVecteur[j].getGroupe())
				{
					matrice[i][j] += 1;
				}
			}
		}

		/*
		cout << endl;
		for (uint32_t i=0; i<15; i++)
		{
			for (uint32_t j=0; j<15; j++)
			{
				cout << (unsigned int) matrice[i][j];
				if (j != 14) cout << " ";
			}
			cout << endl;
		}
		cout << endl;
		*/


		// Ecriture des fichiers intermediaires representants les K-means
		if (fichiersIntermediaires == true)
		{
			output = "";
			if (formatEPS == true) genererEPS(output, pointsVecteur, positionXminParser, positionXmaxParser, positionYminParser, positionYmaxParser, taillePoint);
			else genererCSV(output, pointsVecteur);

			// Creer le fichier
			ofstream myfile;

			if (formatEPS == true) myfile.open (string(argv[1]) + "_kmeans_"+to_string(nombreKmeans)+".eps");
			else myfile.open (string(argv[1]) + "_kmeans_"+to_string(nombreKmeans)+".csv");

			myfile << output;
			myfile.close();
		}
	}


	// Mettre les groupes à -1
	for(uint32_t i = 0; i < pointsVecteur.size(); i++)
	{
		pointsVecteur[i].setGroupe(-1);
	}

	// Point 0
	uint32_t recherche = 0;
	const uint32_t seuil = 10;
	bool pointTrouve = false;
	int compteur = 0;

	while(1)
	{
		// Rechercher un point
		for(uint32_t i = 0; i < pointsVecteur.size(); i++)
		{
			if (pointsVecteur[i].getGroupe() == -1)
			{
				recherche = i;
				pointsVecteur[recherche].setGroupe(compteur);
				pointTrouve = true;
				break;
			}
		}

		if (pointTrouve == true)
		{
			for(uint32_t i = 0; i < pointsVecteur.size(); i++)
			{
				if (i != recherche)
				{
					if (matrice[i][recherche] >= seuilSingleLink)
					{
						pointsVecteur[i].setGroupe(compteur);
					}
				}
			}
			pointTrouve = false;
			compteur++;
		}
		else
		{
			break;
		}
	}

	//cout << "Nombre groupe : " << compteur << endl;

	// Comparer les clusters

	// Groupe 1
	for (uint32_t i = 0; i < compteur; i++)
	{

		bool changerGroupe = false;
		uint32_t groupeAChanger = 0;

		// Point A
		for(uint32_t j = 0; j < pointsVecteur.size(); j++)
		{
			if (pointsVecteur[j].getGroupe() == i)
			{
				// Point B
				for(uint32_t k = 0; k < pointsVecteur.size(); k++)
				{
					// Groupe different
					if(pointsVecteur[k].getGroupe() != i)
					{
						if (matrice[j][k] >= seuilSingleLink)
						{
							// Changement de groupe
							changerGroupe = true;
							groupeAChanger = pointsVecteur[k].getGroupe();
							break;
						}
					}
				}

				if (changerGroupe == true)
				{
					for(uint32_t k = 0; k < pointsVecteur.size(); k++)
					{
						if(pointsVecteur[k].getGroupe() == groupeAChanger)
						{
							pointsVecteur[k].setGroupe(i);
						}
					}
					break;
				}
			}
		}
	}


	output = "";
	if (formatEPS == true) genererEPS(output, pointsVecteur, positionXminParser, positionXmaxParser, positionYminParser, positionYmaxParser, taillePoint);
	else genererCSV(output, pointsVecteur);

	// Creer le fichier
	ofstream myfile;

	if (formatEPS == true) myfile.open (string(argv[1]) + "_final.eps");
	else myfile.open (string(argv[1]) + "_final.csv");

	myfile << output;
	myfile.close();

	// Suppression de la matrice
	for(uint32_t i = 0; i < pointsVecteur.size(); i++)
	{
		delete [] matrice[i];
	}
	delete [] matrice;

	return 0;
}
