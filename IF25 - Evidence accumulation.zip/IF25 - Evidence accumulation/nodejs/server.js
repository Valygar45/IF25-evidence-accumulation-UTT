var express = require('express');
var cookieParser = require('cookie-parser');
var bodyParser = require("body-parser");
var identification = require("./build/Release/identification.node");
var kmeans = require("./build/Release/kmeans.node");
var fileUpload = require('express-fileupload');

var app = express();
app.use(fileUpload());
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


identification.lancerThread();


app.get('/deconnexion.html', function (req, res) {

	var cookie = req.cookies.id;

	if (identification.supprimerID(cookie))
	{
		console.log("Deconnexion de " + cookie);
	}

	res.clearCookie('id').redirect('/index.html');
});

app.get('/index.html', function (req, res) {

	var cookie = req.cookies.id;
	//console.log("Cookies : " + cookie);
	if (identification.verifierID(cookie))
	{
		res.sendFile(__dirname + '/private/index.html');
	}
	else
	{
		res.sendFile(__dirname + '/public/connexion.html');
	}
});

app.get('/demo.html', function (req, res) {

	var cookie = req.cookies.id;
	//console.log("Cookies : " + cookie);
	if (identification.verifierID(cookie))
	{
		res.sendFile(__dirname + '/private/demo.html');
	}
	else
	{
		res.sendFile(__dirname + '/public/connexion.html');
	}
});

app.get('/*', function (req, res) {
	res.redirect('/index.html');
});

app.post('/connexion.html', function (req, res) {
	var expiryDate = new Date(Number(new Date()) + (1 * 3600 * 1000));
	var ID = identification.genererID(64);
	res.cookie('id' , ID, { expires: expiryDate, httpOnly: true }).redirect('/index.html');
});

app.post('/index.html', function (req, res) {
	
	var cookie = req.cookies.id;
	//console.log("Cookies : " + cookie);
	if (identification.verifierID(cookie))
	{
		var nombreKmeans = 10;
		var seuilKmeans = 0.001;
		var nombreCentroides = 10;
		var seuilSingleLink = 5;
		var format = 0;
		var taillePoints = 1;

		if (req.body.nombreKmeans !== undefined)
		{
			if (isNaN(req.body.nombreKmeans) === false)
			{
				nombreKmeans = req.body.nombreKmeans;
			}
		}

		if (req.body.seuilKmeans !== undefined)
		{
			if (isNaN(req.body.seuilKmeans) === false)
			{
				seuilKmeans = req.body.seuilKmeans;
			}
		}

		if (req.body.nombreCentroides !== undefined)
		{
			if (isNaN(req.body.nombreCentroides) === false)
			{
				nombreCentroides = req.body.nombreCentroides;
			}
		}

		if (req.body.seuilSinglelink !== undefined)
		{
			if (isNaN(req.body.seuilSinglelink) === false)
			{
				seuilSingleLink = req.body.seuilSinglelink;
			}
		}

		if (req.body.format !== undefined)
		{
			if (isNaN(req.body.format) === false)
			{
				format = req.body.format;
			}
		}

		if (req.body.taillePoints !== undefined)
		{
			if (isNaN(req.body.taillePoints) === false)
			{
				taillePoints = req.body.taillePoints;
			}
		}

		if (format != 0) format = 1;

		if (req.files['fichier'] !== undefined)
		{
			if (req.files['fichier'].data.length > 0)
			{
				console.log("seuilSingleLink="+seuilSingleLink);
				//kmeans.Kmeans(req.files['fichier'].data, 10, 0.001, 10, 5, 1, function (sortie, temps, reussite) {
				kmeans.Kmeans(req.files['fichier'].data, nombreKmeans, seuilKmeans, nombreCentroides, seuilSingleLink, format, taillePoints, function (sortie, temps, reussite) {
					//console.log(sortie);
					//console.log(sortie.length);
					console.log("reussite="+reussite);

					if (reussite === true)
					{
						console.log("Traitement : " + temps + " ms");
						if (format == 1)
						{
							res.writeHead(200, {
							'Content-Type': 'application/eps',
							'Content-Disposition': 'attachment; filename=graph.eps',
							'Content-Length': sortie.length
							});
							res.end(sortie);
						}
						else
						{
							res.writeHead(200, {
							'Content-Type': 'application/csv',
							'Content-Disposition': 'attachment; filename=graph.csv',
							'Content-Length': sortie.length
							});
							res.end(sortie);
						}
					}
					else
					{
						res.send("Une erreur est survene");
					}
				});
				
			}
			else
			{
				res.send("Le fichier envoyé est vide");
			}
		}
		else
		{
			res.send("Aucun fichier n'a été envoyé");
		}



		//console.log(req.files['fichier'])
		//res.send("Fichier en traitement. Nom du fichier : " + req.files['fichier'].name + ", taille du fichier : " + req.files['fichier'].data.length);
	}
	else
	{
		res.sendFile(__dirname + '/public/connexion.html');
	}
});

app.listen(3000, function () {
	console.log('Service disponible sur le port 3000');
});